# AI聊天应用配置指南

## 🚀 快速开始

恭喜你安装了AI聊天应用！在使用之前需要进行简单的配置。

## 📦 当前默认分发方式

当前默认发布包是 `免安装 EXE 压缩包（ZIP）`。

- 请先完整解压 ZIP
- 再进入 `Xii_Raw_Graph_Portable` 文件夹运行 `ai_chat_app.exe`
- 不建议直接在压缩包预览窗口里双击运行

## 📋 配置步骤

### 1. 获取OpenAI API密钥

1. 访问 [OpenAI官网](https://platform.openai.com/)
2. 登录或注册账户
3. 进入API Keys页面
4. 创建新的API密钥
5. **重要**: 复制并安全保存密钥（显示一次后将不可见）

### 2. 配置应用

#### 方法一：设置环境变量

1. 右键点击"此电脑" → "属性" → "高级系统设置"
2. 点击"环境变量"
3. 在"用户变量"或"系统变量"中点击"新建"
4. 变量名: `OPENAI_API_KEY`
5. 变量值: `sk-your-actual-api-key-here`
6. 保存并重新启动应用

#### 方法二：创建配置文件

如果你更习惯使用 `.env` 文件，推荐放到：

```text
%LOCALAPPDATA%\Xii_Raw Graph\.env
```

文件内容示例：

```env
OPENAI_API_KEY=sk-your-actual-api-key-here
```

保存后重新启动应用即可。

#### 方法三：便携版目录下创建 `.env`

如果你运行的是便携版，可以直接把程序目录里的 `.env.example` 复制并重命名为 `.env`，再填入真实 Key。

### 3. 验证配置

启动应用，如果配置正确，你应该能够正常与AI对话。

## ⚠️ 重要提醒

- **API密钥安全**: 不要将API密钥告诉他人或上传到任何地方
- **费用提醒**: OpenAI API按使用量收费，请合理使用
- **密钥管理**: 如果怀疑密钥泄露，请立即在OpenAI官网删除并重新生成

## 🆘 遇到问题？

如果应用无法正常工作：

1. 检查 `.env` 文件是否存在且格式正确
2. 确认 `.env` 文件放在用户目录或便携版目录
3. 确认API密钥有效且有余额
4. 尝试重启应用
5. 检查网络连接

## 💡 高级配置

### 自定义API端点

如果你使用其他兼容OpenAI API的服务，可以添加以下配置：

```
OPENAI_API_KEY=your-api-key
OPENAI_BASE_URL=https://your-custom-endpoint.com/v1
```

---

配置完成后，享受与AI的智能对话吧！🤖✨
