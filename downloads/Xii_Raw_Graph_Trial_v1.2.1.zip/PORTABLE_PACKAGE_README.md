# 便携版使用说明

这是当前默认发布方式：`免安装 EXE 压缩包（ZIP）`。

## 用户使用步骤

1. 下载并解压 ZIP 包
   请先完整解压，不要直接在压缩包预览窗口里运行程序。

2. 解压后直接双击 `ai_chat_app.exe`

3. 首次使用时配置 `OPENAI_API_KEY`
   可以按 `USER_SETUP_GUIDE.md` 中的说明设置环境变量，或把程序目录里的 `.env.example` 复制并重命名为 `.env` 后填写自己的 Key。

## 更新方式

- 新版本会通过 GitHub 仓库下载页和 GitHub Pages 下载页发布
- 建议重新下载最新 ZIP，解压到新的文件夹后再替换旧版本

## 下载异常兜底

如果 GitHub 页面或下载链接暂时无法访问，请查看同目录的 `CONTACT_AUTHOR_WX.txt`。
